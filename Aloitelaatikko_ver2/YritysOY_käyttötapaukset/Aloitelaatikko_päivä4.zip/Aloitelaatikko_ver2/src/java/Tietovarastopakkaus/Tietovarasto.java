/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tietovarastopakkaus;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author haaar
 */
public class Tietovarasto {
    
    // Yhteysmuuttujat
    private String ajuri;
    private String url;
    private String kayttajatunnus;
    private String salasana;

    public Tietovarasto(String ajuri, String url, String kayttajatunnus, String salasana) {
        this.ajuri = ajuri;
        this.url = url;
        this.kayttajatunnus = kayttajatunnus;
        this.salasana = salasana;
    }
    
    public Tietovarasto(){
        this("com.mysql.Driver", "jdbc:mysql://localhost:3306/aloitelaatikko", "root", "");
    }
    
    public boolean lisaaKayttaja(Kayttaja kayttaja){
        Connection yhteys = null;
        PreparedStatement lisayslause = null;
        
        try{
            // Otetaan yhteys tietokantaan
            yhteys = YhteydenHallinta.avaaYhteys(ajuri, url, kayttajatunnus, salasana);
            //jos yhteyttä ei saada, niin palautetaan false
            if(yhteys == null){
                return false;
            }
            
            // Määritellään lisäystä varten SQL-lauseet
            String lisaaKayttajaSQL = "insert into kayttajat values(?,?,?,?,?,?,?,?)";
            
            // Valmistellaan SQL-lause tietokantapalvelinta varten
            
            // Tämä upuu --> lisayslause = yhteys.prepareStatement(lisaaKayttajaSQL);
            
            lisayslause.setInt(1, kayttaja.getKayttajaID());
            lisayslause.setString(2, kayttaja.getEtunimi());
            lisayslause.setString(3, kayttaja.getSukunimi());
            lisayslause.setString(4, kayttaja.getEmail());
            lisayslause.setString(5, kayttaja.getKayttajaTunnus());
            lisayslause.setString(6, kayttaja.getSalasana());
            lisayslause.setString(7, kayttaja.getPuhelin());
            lisayslause.setString(8, kayttaja.getLuontipaivays());
            // Suoritetaan palvelimella SQL-lause
            return lisayslause.executeUpdate() > 0;
        }catch(Exception ex){
            // Jos tuli virhe, niin hypätään tänne
            ex.getMessage();
            return false;
        }finally{
           // Suljetaan yhteysx tietokantaa
           YhteydenHallinta.suljeLause(lisayslause);
           YhteydenHallinta.suljeYhteys(yhteys);
        }    
    }
}
